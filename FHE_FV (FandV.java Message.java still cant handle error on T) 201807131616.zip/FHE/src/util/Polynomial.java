package util;

import static util.Const.ONE;
import static util.Const.TWO;
import static util.Const.ZERO;
import static util.Polynomial.GaussianSampling;
import static util.Polynomial.RqSampling;
import static util.Polynomial.randomInt;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.mathIT.algebra.PolynomialZ;

public class Polynomial {
	public static Random random = new Random();

	/// sample a integer from [low, high] ///
	public static int randomInt(int low, int high)
	{   
        return (random.nextInt(high-low+1) + low);
    }
	
	//  Step.1 The secret key, Ks, is simply a uniform random draw from R2(-1,1].
	//         sample a 2^(d-1) binary vector for the polynomial coefficients.		
	/// SecretKeyGen(lambda): Sample s <- R2 and output sk = s.
	public static PolynomialZ R2Sampling(int length) {
		PolynomialZ sk = new PolynomialZ();

		for (long i = 0; i < length; i++) {
			int r = randomInt(0, 1);
			sk.put(BigInteger.valueOf(i), BigInteger.valueOf(r));
		}
		
		return sk;
	}
	
	/**
	 * BigInteger(int numBits, Random rnd) Constructs a randomly generated BigInteger, uniformly distributed over the range [0,   2^numBits - 1].
	 * using this function to get a BigInteger from Rq = {n: -q/2<n<=q/2 } = (-q/2, q/2] = [-q/2+1, q/2].
	 * @param The BigInteger q
	 * @return a BigInteger
	 */
	public static BigInteger RqSampling(BigInteger q)
	{
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		
		///step 1. get a random BigInteger bi from [0, 2^qn).///		
		BigInteger bi = new BigInteger(qn,random);
		///step 2. if bi > q/2 : bi -= q . that make bi shift to [-q/2+1, q/2].///
		if( bi.compareTo(q.divide(TWO)) > 0) 
			bi = bi.subtract(q);
		
		return bi;
	}
	// a ~ Rq
	public static PolynomialZ RqSampling(BigInteger q, int length)
	{
		PolynomialZ a = new PolynomialZ();
		for(int i=0;i<length;i++) {
			BigInteger coefficient = RqSampling(q);
			a.put(BigInteger.valueOf(i), coefficient);
		}
		
		return a;
	}
	
	/**
	 * @param mu(μ)  : a mean μ(mu);
	 * @param tau(τ) : a tail-cut parameter τ(tau)
	 * @param sigma  : a specific standard deviation σ(sigma)
	 * @return a integer from a bounded discrete Gaussian distribution draw.
	 */
	public static int GaussianSampling(int sigma)
	{	
		final int mu = 0;
		final int tau = 10;

		int Xmax = mu + tau*sigma;
		int Xmin = mu - tau*sigma;

		while(true)
		{
			int x = randomInt(Xmin,Xmax);
			double p = 1.0/Math.sqrt(2*Math.PI)/sigma * Math.pow(Math.E, -0.5*(x-mu)/sigma*(x-mu)/sigma);
			double r = random.nextDouble();
			if(r < p) return x;
		}
	}
	public static PolynomialZ GaussianSampling(int sigma, int length)
	{	
		PolynomialZ e = new PolynomialZ();
		for(int i=0;i<length;i++) {
			BigInteger coefficient = BigInteger.valueOf(GaussianSampling(sigma));
			e.put(BigInteger.valueOf(i), coefficient);
		}
		
		return e;
	}


	
	/**
	 * @param res  : the polynomial
	 * @param q    : from Rq = Zq[x]/... . 
	 * @return the res with coefficients that have been Centered. 
	 */
	public static PolynomialZ CentredCoeff(PolynomialZ res, BigInteger q)
	{
		/// res is a map of < exponent, coefficient >. ///
		for(BigInteger idx : res.keySet())
		{
			BigInteger value = res.get(idx);
			value = value.mod(q);
			
			/// get i = q/2. ///
			BigInteger i;// i=n for q=2n+1or2n   BigInteger.getLowestSetBit() 
			if(q.mod(BigInteger.TWO).equals(BigInteger.ZERO))
				i = q.divide(BigInteger.TWO); // or just BigInteger i = q.divide(BigInteger.TWO);
			else
				i = q.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			
			/// if value>q/2 : value -= q. so that the coefficient shifts. ///
			if(value.compareTo(i) > 0)
				value = value.subtract(q);
			
			res.put( idx, value );
		}
		
		return res;
	}
	
	public static PolynomialZ MOD(PolynomialZ x, PolynomialZ y)
	{
		BigInteger degX = x.getDegree();
		BigInteger degY = y.getDegree();
		
		if(degX.compareTo(degY)>0)
			return x=x.mod(y);
		else
		if(degX.compareTo(degY)==0)
		{
			if(x.get(degX).compareTo(y.get(degY))>=0) // also need: [x.get(degX)] %  [y.get(degY)] == 0
				return x=x.mod(y);
			else
				return x; /// will not happen in the case of g(x)%(x^n + 1)!
			}
		else
		if(degX.compareTo(degY)<0)
			return x;
		
		return new PolynomialZ();
	}
	
	public static void print(PolynomialZ r) {
		
		int c=0;
		System.out.print("( ");
		String gap = "    ";
		List<BigInteger> idxs = new ArrayList<BigInteger>(r.keySet());
		for(BigInteger i : idxs )
		{
			if(r.get(i)!=null && r.get(i).compareTo(ZERO)!=0)
			{
				if(i.equals(ZERO)) {
					System.out.print(r.get(i));
					continue;
				}
				if(i.equals(ONE)) {
					if(r.get(i).compareTo(ONE)!=0)
					{
						System.out.print(r.get(i)+ "x" + gap + "+" + gap );
					    continue;
					}else {
						System.out.print("x" + gap + "+" + gap );
					    continue;
					}
				}
				
				if(r.get(i).equals(ONE)) 
					System.out.print("x^" + i + gap + "+" + gap);
				else   
					System.out.print(r.get(i)+ "x^" + i + gap + "+" + gap);
				
				c++;
				if(c>12) {
					System.out.print("..." + gap);
					break;
				}
			}
		}
		System.out.print(" )");
	}
	
	
}
