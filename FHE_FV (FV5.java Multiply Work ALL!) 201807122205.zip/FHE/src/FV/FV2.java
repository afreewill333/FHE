package FV;

import java.io.*;
import java.util.*;
import java.math.*;

import org.mathIT.algebra.PolynomialZ;


public class FV2{
	private static Random random = new Random();
	private static BigInteger ZERO = BigInteger.ZERO;
	private static BigInteger ONE = BigInteger.ONE;
	private static BigInteger TWO = new BigInteger("2");
		
	/// sample a integer from [low, high] ///
	private static int randomInt(int low, int high)
	{   
        return (random.nextInt(high-low+1) + low);
    }
	
	/**
	 * BigInteger(int numBits, Random rnd) Constructs a randomly generated BigInteger, uniformly distributed over the range [0,   2^numBits - 1].
	 * using this function to get a BigInteger from Rq = {n: -q/2<n<=q/2 } = (-q/2, q/2] = [-q/2+1, q/2].
	 * @param The BigInteger q
	 * @return a BigInteger
	 */
	private static BigInteger RqSampling(BigInteger q)
	{
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		
		///step 1. get a random BigInteger bi from [0, 2^qn).///		
		BigInteger bi = new BigInteger(qn,random);
		///step 2. if bi > q/2 : bi -= q . that make bi shift to [-q/2+1, q/2].///
		if( bi.compareTo(q.divide(TWO)) > 0) 
			bi = bi.subtract(q);
		
		return bi;
	}
	
	/**
	 * @param mu(μ)  : a mean μ(mu);
	 * @param tau(τ) : a tail-cut parameter τ(tau)
	 * @param sigma  : a specific standard deviation σ(sigma)
	 * @return a integer from a bounded discrete Gaussian distribution draw.
	 */
	private static int GaussianSampling(int sigma)
	{	
		final int mu = 0;
		final int tau = 10;

		int Xmax = mu + tau*sigma;
		int Xmin = mu - tau*sigma;

		while(true)
		{
			int x = randomInt(Xmin,Xmax);
			double p = 1.0/Math.sqrt(2*Math.PI)/sigma * Math.pow(Math.E, -0.5*(x-mu)/sigma*(x-mu)/sigma);
			double r = random.nextDouble();
			if(r < p) return x;
		}
	}
	
	/**
	 * @param res  : the polynomial
	 * @param q    : from Rq = Zq[x]/... . 
	 * @return the res with coefficients that have been Centered. 
	 */
	private static PolynomialZ CentredCoeff(PolynomialZ res, BigInteger q)
	{
		/// res is a map of < exponent, coefficient >. ///
		for(BigInteger idx : res.keySet())
		{
			BigInteger value = res.get(idx);
			value = value.mod(q);
			
			/// get i = q/2. ///
			BigInteger i;// i=n for q=2n+1or2n   BigInteger.getLowestSetBit() 
			if(q.mod(BigInteger.TWO).equals(BigInteger.ZERO))
				i = q.divide(BigInteger.TWO); // or just BigInteger i = q.divide(BigInteger.TWO);
			else
				i = q.subtract(BigInteger.ONE).divide(BigInteger.TWO);
			
			/// if value>q/2 : value -= q. so that the coefficient shifts. ///
			if(value.compareTo(i) > 0)
				value = value.subtract(q);
			
			res.put( idx, value );
		}
		
		return res;
	}
	
	private static PolynomialZ MOD(PolynomialZ x, PolynomialZ y)
	{
		BigInteger degX = x.getDegree();
		BigInteger degY = y.getDegree();
		
		if(degX.compareTo(degY)>0)
			return x=x.mod(y);
		else
		if(degX.compareTo(degY)==0)
		{
			if(x.get(degX).compareTo(y.get(degY))>=0) // also need: [x.get(degX)] %  [y.get(degY)] == 0
				return x=x.mod(y);
			else
				return x; /// will not happen in the case of g(x)%(x^n + 1)!
			}
		else
		if(degX.compareTo(degY)<0)
			return x;
		
		return new PolynomialZ();
	}
	private static void print(PolynomialZ r) {
		
		int c=0;
		System.out.print("( ");
		String gap = "    ";
		List<BigInteger> idxs = new ArrayList<BigInteger>(r.keySet());
		for(BigInteger i : idxs )
		{
			if(r.get(i)!=null && r.get(i).compareTo(ZERO)!=0)
			{
				if(i.equals(ZERO)) {
					System.out.print(r.get(i));
					continue;
				}
				if(i.equals(ONE)) {
					if(r.get(i).compareTo(ONE)!=0)
					{
						System.out.print(r.get(i)+ "x" + gap + "+" + gap );
					    continue;
					}else {
						System.out.print("x" + gap + "+" + gap );
					    continue;
					}
				}
				
				if(r.get(i).equals(ONE)) 
					System.out.print("x^" + i + gap + "+" + gap);
				else   
					System.out.print(r.get(i)+ "x^" + i + gap + "+" + gap);
				
				c++;
				if(c>12) {
					System.out.print("..." + gap);
					break;
				}
			}
		}
		System.out.print(" )");
	}

	public static void main(String[] args){
		// 1s = 10^3ms = 10^6us = 10^9ns
		long beg = System.nanoTime();

		/**
		 * Notation:
		 *   q     : modulus in the cipher text space(coefficient modulus) of the form q1*q2*...*qk,where qi are prime
		 *   t     : modulus in the plain text space(plain text modulus)
		 *   x^n+1 : The polynomial modulus which specifies the ring R
		 *   R     : The ring Z[x]/f(x), where f(x) =(x^n+1)=x^(2^(d-1))+1
		 *   Ra    : The ring Za[x]/(x^n+1),i.e. same as the ring R but with coefficients reduced modulo a
		 *   det   : Quotient on division of q by t, or [q/t]
		 *   rt(q) : Remainder on division of q by t, i.e. q = det*t + rt(q), where 0<=rt(q)<t
		 *   X     : Error distribution(a truncated discrete Gaussian distribution)
		 *   sigma : Standard deviation of X
		 *   B     : Bound on the distribution X
		 *   Zq[x] : denote polynomial whose coefficients belong to Zq.
		 *   Zq    : is the set of integers {n: -q/2<n<=q/2 }.
		 *   Rq    : Zq[x]/(x^(2^(d-1)) +1 )
		 *   ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
		 *   d     : 13(4095 degree polynomials)
		 *   q     : 2^128
		 *   T     : 2^64(Relinearisation: Version 1 need T. Here Set T a pow of two for convenience)
		 *   t     : 2^15
		 *   σ     : 16(sigma)
		 *   
		 *   The scheme FV : SecretKeyGen,PublicKeyGen,EvaluationKeyGen,Encrypt,Decrypt,Add and Multiply.
		 */
		int d = 6;// polynomial.degree=4095 
		BigInteger q = TWO.pow(128);
		BigInteger T = TWO.pow(64);
		BigInteger t = TWO.pow(15);
		int sigma = 16;
		PolynomialZ Phi = new PolynomialZ();///cyclotomic polynomial (x^(2^(d-1)) +1 )
		Phi.put(TWO.pow(d-1), ONE);
		Phi.put(ZERO, ONE);
		
		//Stage.1 Key Generation
		//  Step.1 The secret key, Ks, is simply a uniform random draw from R2(-1,1].
		//         sample a 2^(d-1) binary vector for the polynomial coefficients.		
		/// SecretKeyGen(lambda): Sample s <- R2 and output sk = s.
		PolynomialZ sk = new PolynomialZ();
		long length = (long) Math.pow(2, d-1);
		
		for(long i=0;i<length;i++) {
			int r = randomInt(0,1);
			sk.put(BigInteger.valueOf(i), BigInteger.valueOf(r));
		}
		PolynomialZ s = sk;
		//  Step.2 The public key, Kp, is a vector containing two polynomials:
		//         Kp = (Kp1, Kp2) = ([-(a*Ks + e)]q, a)   a ~ Rq, e ~ X(0,σ)
		/// PublicKeyGen(sk): Set s = sk, sample a <- Rq, and e <- X. Output pk = ([-(a*s+e)]q, a).
		PolynomialZ a = new PolynomialZ();
		for(long i=0;i<length;i++) {
			BigInteger coefficient = RqSampling(q);
			a.put(BigInteger.valueOf(i), coefficient);
		}
		PolynomialZ e = new PolynomialZ();
		for(long i=0;i<length;i++) {
			BigInteger coefficient = BigInteger.valueOf(GaussianSampling(sigma));
			e.put(BigInteger.valueOf(i), coefficient);
		}
		
		PolynomialZ p0 = a.multiply(s); p0 = MOD(p0, Phi);
		p0 = p0.plus(e);PolynomialZ zero = new PolynomialZ();
		p0 = zero.minus(p0);
		CentredCoeff(p0, q);
		PolynomialZ p1 = a;
		//  Step.3 The relinearisation key, rlk, ...		
		/// EvaluationKeyGen(sk,w): For i{0,...,l},sample ai <- Rq, ei <- X. Output
		///                        evk = ([-(ai*s + ei) + w^i*s^2]q, ai).
		
		//Stage.2 Encryption
		//  Step.1 An integer message m is first represented as m(x)∈ Rt.
		BigInteger message =  BigInteger.valueOf(36);
		PolynomialZ mx = new PolynomialZ();
		long deg = 0;
		for(char ch : message.toString(2).toCharArray())
		{////////////////should rewrite!///////////////////
			mx.put(BigInteger.valueOf(message.toString(2).length()-deg-1), BigInteger.valueOf(ch-'0'));// work when base<10
			deg++;
		}
		//  Step.2 Encryption then renders a cipher text which is a vector containing two polynomials:
		//         c = (c1,c2) = ( [Kp1*u + e1 + det*m(x)]q, [Kp2*u + e2]q )
		//         u,e1,e2 ~ X(0,σ)   det = [q/t] 
		/// Encrypt(pk,m): For m in Rt, let pk=(p0,p1).Sample u <- R2, and e1,e2 <- X. Compute
		///                         ct = ([det*m + p0*u +e1]q, [p1*u + e2]q)
		PolynomialZ det = new PolynomialZ(ZERO, q.divide(t));
		PolynomialZ u  = new PolynomialZ();
		PolynomialZ e1 = new PolynomialZ();
		PolynomialZ e2 = new PolynomialZ();
		for(long i=0;i<length;i++) {
			u.put(BigInteger.valueOf(i), BigInteger.valueOf(randomInt(0,1)));
			e1.put(BigInteger.valueOf(i), BigInteger.valueOf(GaussianSampling(sigma)));
			e2.put(BigInteger.valueOf(i), BigInteger.valueOf(GaussianSampling(sigma)));
		}
		
		PolynomialZ c0 = det.multiply(mx);
		PolynomialZ p0u = p0.multiply(u);
		p0u = MOD(p0u, Phi);
		c0 = c0.plus(p0u).plus(e1);
		CentredCoeff(c0, q);
	
		PolynomialZ c1 = p1.multiply(u);
		c1 = MOD(c1, Phi);
		c1 =c1.plus(e2);
		CentredCoeff(c1, q);
	
		//Stage.3 Decryption
		//  Step.1 decryption of a cipher text c is by evaluating:
		//              m0(x) = [ [t*[c1 + c2*Ks]q / q ] ]t
		//         so that m = m0(x).		
		/// Decrypt(sk,ct): Set s = sk, c0 = ct[0], and c1 = ct[1]. Output
		PolynomialZ result = c1.multiply(s);
		result = MOD(result, Phi);
		result = c0.plus(result);
		CentredCoeff(result, q);
		
		BigDecimal tlq = new BigDecimal(t).divide(new BigDecimal(q));
		for(BigInteger idx : result.keySet()) {
			BigDecimal coefficient = tlq.multiply( new BigDecimal(result.get(idx)) );
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			result.put(idx, coefficient.toBigInteger());			
		}
		CentredCoeff(result, t);
		
		System.out.println("m(2) = " + result.evaluate(TWO));
		System.out.print("\nmx     = ");print(mx);
		System.out.print("\nresult = ");print(result);
			
		long end = System.nanoTime();
		System.out.println();
		System.out.println("end-beg = " + (int)(end-beg)/1e9 +"s." );
		
		System.out.println("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~the same secret key, the same public key~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~");

		//Stage.2 Encryption
		//  Step.1 An integer message m is first represented as m(x)∈ Rt.
		BigInteger message2 =  BigInteger.valueOf(28);
		PolynomialZ mx2 = new PolynomialZ();
		long deg2 = 0;
		for(char ch : message2.toString(2).toCharArray())
		{////////////////should rewrite!///////////////////
			mx2.put(BigInteger.valueOf(message2.toString(2).length()-deg2-1), BigInteger.valueOf(ch-'0'));// work when base<10
			deg2++;
		} 
		//  Step.2 Encryption then renders a cipher text which is a vector containing two polynomials:
		//         c = (c1,c2) = ( [Kp1*u + e1 + det*m(x)]q, [Kp2*u + e2]q )
		//         u,e1,e2 ~ X(0,σ)   det = [q/t] 
		/// Encrypt(pk,m): For m in Rt, let pk=(p0,p1).Sample u <- R2, and e1,e2 <- X. Compute
		///                         ct = ([det*m + p0*u +e1]q, [p1*u + e2]q)
		PolynomialZ det2 = new PolynomialZ(ZERO, q.divide(t));
		PolynomialZ u2  = new PolynomialZ();
		PolynomialZ e12 = new PolynomialZ();
		PolynomialZ e22 = new PolynomialZ();
		for(long i=0;i<length;i++) {
			u2.put(BigInteger.valueOf(i), BigInteger.valueOf(randomInt(0,1)));
			e12.put(BigInteger.valueOf(i), BigInteger.valueOf(GaussianSampling(sigma)));
			e22.put(BigInteger.valueOf(i), BigInteger.valueOf(GaussianSampling(sigma)));
		}
		
		PolynomialZ c02 = det2.multiply(mx2);
		PolynomialZ p0u2 = p0.multiply(u2);
		p0u2 = MOD(p0u2, Phi);
		c02 = c02.plus(p0u2).plus(e12);
		CentredCoeff(c02, q);
	
		PolynomialZ c12 = p1.multiply(u2);
		c12 = MOD(c12, Phi);
		c12 =c12.plus(e22);
		CentredCoeff(c12, q);
	
		//Stage.3 Decryption
		//  Step.1 decryption of a cipher text c is by evaluating:
		//              m0(x) = [ [t*[c1 + c2*Ks]q / q ] ]t
		//         so that m = m0(x).		
		/// Decrypt(sk,ct): Set s = sk, c0 = ct[0], and c1 = ct[1]. Output
		PolynomialZ result2 = c12.multiply(s);
		result2 = MOD(result2, Phi);
		result2 = c02.plus(result2);
		CentredCoeff(result2, q);
		
		// should make tlq be a attribute
		for(BigInteger idx : result2.keySet()) {
			BigDecimal coefficient = tlq.multiply( new BigDecimal(result2.get(idx)) );
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			result2.put(idx, coefficient.toBigInteger());			
		}
		CentredCoeff(result2, t);
		
		System.out.println("m2(2) = " + result2.evaluate(TWO));
		System.out.print("\nmx     = ");print(mx2);
		System.out.print("\nresult2 = ");print(result2);
			
		long end1 = System.nanoTime();
		System.out.println();
		System.out.println("end2-end = " +  (int)(end1-end)/1e9 +"s." );

		/// (c0 c1)  (c02,c12) ///
		PolynomialZ c2 = c02;
		PolynomialZ c3 = c12;
		System.out.println("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~Add(ct0,ct1):Output(ct0[0]+ct1[0],ct0[1]+ct1[1])~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~");
		/// (c0 c1)  (c02,c12) ///		
		PolynomialZ C0 = c0.plus(c02);//CentredCoeff(C0, q);
		PolynomialZ C1 = c1.plus(c12);//CentredCoeff(C1, q);
		
		PolynomialZ sum = C1.multiply(s);
		sum = MOD(sum, Phi);
		sum = C0.plus(sum);
		CentredCoeff(sum, q);
		
		for(BigInteger idx : sum.keySet()) {
			BigDecimal coefficient = tlq.multiply( new BigDecimal(sum.get(idx)) );
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			sum.put(idx, coefficient.toBigInteger());			
		}
		CentredCoeff(sum, t);
		
		System.out.println("sum(2) = " + sum.evaluate(TWO) + " = " + message + " + "+message2+" = " + message.add(message2) );
		System.out.print("\nsum     = ");print(sum);
		
		PolynomialZ C2;
		/// (c0 c1)  (c02,c12) ///
		/// PolynomialZ c2 = c02;
		/// PolynomialZ c3 = c12;
		System.out.println();
		PolynomialZ c00 = c0;
		PolynomialZ c01 = c1;		
		PolynomialZ c10 = c02;
		PolynomialZ c11 = c12;
		System.out.println("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~Multiply(ct0,ct1)~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~");
				
		///EvaluationKeyGen(sk,w): for i{0,...,l}, sample  ai <- Rq,  ei <- X. Output
		///                        evk = ([-(ai*s+e) + w^i*s^2]q, ai).
		/**
		 * Notation:
		 *   A first possible solution is to slice C2 into parts of small norm by choosing a base T
		 *   ( note that T is totally independent of t) and to write C2 in base T,i.e. C2=T^i*C2[i] mod q (i{0...l}),
		 *   with l = [log(q)/log(T)] and the coefficients of C2[i] are in R[T]{(-T/2, T/2])}.
		 *   The relinearisation key rlk then consists of the masked version of T^i*s*s for i=0,...,l:
		 *     rlk = [ ([-(ai*s + ei) + T^i*s*s]q, ai) :  i{0,...,l}]
		 */
		///get the qn of q = 2^qn from q.///
		int qn;
		if(q.compareTo(ZERO)<0)
			qn = q.bitLength();
		else
			qn = q.bitLength() - 1;
		///get the Tn of T = 2^Tn from T.///
		int Tn;
		if(T.compareTo(ZERO)<0)
			Tn = T.bitLength();
		else
			Tn = T.bitLength() - 1;
		int l = qn / Tn; // l = [log(q)/log(T)] = qn/Tn

		PolynomialZ[][] relinkey = new PolynomialZ[l+1][2];
		for (int i = 0; i <= l; i++) {
			PolynomialZ ai = new PolynomialZ();
			for (long ii = 0; ii < length; ii++) {
				BigInteger coefficient = RqSampling(q);
				a.put(BigInteger.valueOf(ii), coefficient);
			}
			PolynomialZ ei = new PolynomialZ();
			for (long ii = 0; ii < length; ii++) {
				BigInteger coefficient = BigInteger.valueOf(GaussianSampling(sigma));
				ei.put(BigInteger.valueOf(ii), coefficient);
			}

			PolynomialZ k0 = ai.multiply(s);
			k0 = MOD(k0, Phi);
			k0 = k0.plus(ei);
			k0 = zero.minus(k0);
			PolynomialZ ss = s.multiply(s);
			ss = MOD(ss, Phi);
			PolynomialZ Ti = new PolynomialZ(ZERO, T.pow(i));
			PolynomialZ tmp = Ti.multiply(ss);
			tmp = MOD(tmp, Phi);
			k0 = k0.plus(tmp);
			CentredCoeff(k0, q);
			relinkey[i][0] = k0;
			relinkey[i][1] = ai;
		}

		long end2 = System.nanoTime();
		/// Mul(ct1,ct2,rlk): compute
		C0 = c00.multiply(c10);
		C0 = MOD(C0, Phi);
		for (BigInteger idx : C0.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(C0.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			C0.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(result2, q);

		C1 = c00.multiply(c11);
		C1 = MOD(C1, Phi);
		PolynomialZ temp = c01.multiply(c10);
		temp = MOD(temp, Phi);
		C1 = C1.plus(temp);
		for (BigInteger idx : C1.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(C1.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			C1.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(C1, q);

		C2 = c01.multiply(c11);
		C2 = MOD(C2, Phi);
		for (BigInteger idx : C2.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(C2.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			C2.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(C2, q);

		PolynomialZ Ct0 = C0;
		PolynomialZ Ct1 = C1;
		for (int i = 0; i < l; i++) {
			PolynomialZ C2i = new PolynomialZ();
			for(BigInteger idx : C2.keySet()) {
				BigInteger coefficient = C2.get(idx).mod(T);
				C2i.put(idx, coefficient);
				
				coefficient = C2.get(idx).divide(T);
				C2.put(idx, coefficient);				
			}
			CentredCoeff(C2i, T);
			temp = relinkey[i][0].multiply(C2i);
			Ct0 = Ct0.plus(temp);
			temp = relinkey[i][1].multiply(C2i);
			Ct1 = Ct1.plus(temp);
		}
		CentredCoeff(Ct0, q);
		CentredCoeff(Ct1, q);
		
		// decrypt works! Ct0 = c0; Ct1 = c1;
		PolynomialZ product = Ct1.multiply(s);
		product = MOD(product, Phi);
		product = Ct0.plus(product);
		CentredCoeff(product, q);
		for (BigInteger idx : product.keySet()) {
			BigDecimal coefficient = tlq.multiply(new BigDecimal(product.get(idx)));
			coefficient = coefficient.setScale(0, RoundingMode.HALF_DOWN);
			product.put(idx, coefficient.toBigInteger());
		}
		CentredCoeff(product, t);

		System.out.println();
		System.out.println("product(2) = " + product.evaluate(TWO) + " = " + message + " * " + message2 + " = "
				+ message.multiply(message2));
		System.out.print("\nproduct     = ");
		print(product);

		long end3 = System.nanoTime();
		System.out.println();
		System.out.println("one sigle multiply = " + (int) (end3 - end2) / 1e9 + "s.");

	}

}